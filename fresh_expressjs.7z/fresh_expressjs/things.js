var express=require('express')
var router=express.Router();
router.get('/',function(req, res) {
	res.send('GET requests here.')
});

router.post('/',function(req, res) {
	res.send('post requests here.')
})

module.exports=router;